package com.mohit.task.service;

import com.mohit.task.dto.Task;
import com.mohit.task.dto.TaskRequest;
import com.mohit.task.dto.TaskResponse;
import com.mohit.task.repository.ITaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TaskService {
    private final ITaskRepository taskRepository;

    public List<Task> getTasks() throws RuntimeException {
        return this.taskRepository.findAll();
    }

    public Task getTask(String id) throws RuntimeException {
        return taskRepository.findById(id).orElse(null);
    }

    public String deleteTask(String id) throws RuntimeException {
        this.taskRepository.deleteById(id);
        return id;
    }

    public TaskResponse addTask(TaskRequest taskRequest) throws RuntimeException {
        Task task = new Task(taskRequest);

        this.taskRepository.save(task);
        return new TaskResponse(task);
    }

    public TaskResponse updateTask(String id, Task task) throws IllegalArgumentException {
        if (!id.equals(task.getId())) {
            throw new IllegalArgumentException("Task id does not match");
        }

        if (taskRepository.existsById(id)) {
            this.taskRepository.save(task);
            return new TaskResponse(task);
        }

        throw new IllegalArgumentException("Task id not found");
    }
}
