package com.mohit.task.enums;

public enum EStatus {
    TODO,
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
}
