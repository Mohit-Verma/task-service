package com.mohit.task.controller;

import com.mohit.task.dto.Task;
import com.mohit.task.dto.TaskRequest;
import com.mohit.task.dto.TaskResponse;
import com.mohit.task.service.TaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1")
public class TaskController {
    private final TaskService taskService;

    @GetMapping("/tasks")
    public ResponseEntity<List<TaskResponse>> getAllTasks() throws RuntimeException {
        List<TaskResponse> response = taskService.getTasks()
                .stream().map(TaskResponse::new).toList();
        return ResponseEntity.ok(response);
    }

    @GetMapping("/tasks/{id}")
    public ResponseEntity<TaskResponse> getTaskById(@PathVariable String id) throws RuntimeException {
        Task task = taskService.getTask(id);

        if (task != null) {
            return ResponseEntity.ok(new TaskResponse(task));
        }

        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/tasks/{id}")
    public ResponseEntity<String> deleteTaskById(@PathVariable String id) throws RuntimeException {
        taskService.deleteTask(id);
        return ResponseEntity.ok(id);
    }

    @PutMapping("/tasks/{id}")
    public ResponseEntity<TaskResponse> updateTask(@PathVariable String id, @RequestBody Task task) throws RuntimeException {
        TaskResponse response = taskService.updateTask(id, task);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/tasks")
    public ResponseEntity<TaskResponse> createTask(@RequestBody TaskRequest taskRequest) throws RuntimeException {
        TaskResponse response = taskService.addTask(taskRequest);
        return ResponseEntity.ok(response);
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<String> handleException(Exception e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }
}
